package com.hellokoding.springmvc;

import java.util.List;

import com.model.PictureSumModel;

public interface IAPIService {

	public List<PictureSumModel> getAPIDetails();
}
