package com.hellokoding.springmvc;

import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.List;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.PictureSumModel;

@Service
public class APIServiceImpl implements IAPIService {

	private String url = "https://picsum.photos/v2/list?page=1&limit=100";

	@Override
	public List<PictureSumModel> getAPIDetails() {

		try {

			URI uri = new URI(url);
			ResponseEntity<String> result = getRestTemplate().getForEntity(uri, String.class);
			if (result.getStatusCode().equals(HttpStatus.OK)) {
				System.out.println("value:\t" + result.getBody());
				List<PictureSumModel> values=getLisOfObjects(result.getBody());
				values.get(0).setDownload_url(Base64.getEncoder().encodeToString(values.get(0).getDownload_url().getBytes()));
				
				return values;
				
			}
		} catch (URISyntaxException | JsonProcessingException | RestClientException | KeyManagementException | KeyStoreException | NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return null;

	}

	private List<PictureSumModel> getLisOfObjects(String json) throws JsonMappingException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.readValue(json, new TypeReference<List<PictureSumModel>>() {
		});

	}

	public RestTemplate getRestTemplate() throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
		org.apache.http.conn.ssl.TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

		SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy)
				.build();

		SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();

		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();

		requestFactory.setHttpClient(httpClient);
		RestTemplate restTemplate = new RestTemplate(requestFactory);
		return restTemplate;
	}

}

